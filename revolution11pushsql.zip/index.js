const platform = process.env.DB_PLATFORM;
const name = process.env.DB_NAME;
const table = process.env.DB_TABLE;
const column = process.env.DB_COLUMN;
const user = process.env.DB_USER;
const password = process.env.DB_PASS;
const host = process.env.DB_HOST;
const port = process.env.DB_PORT;

var sworm = require('sworm');


exports.handler = (event) => {
	console.log(`Sending to ${host}:${port}`);

	var db = sworm.db({
	  driver: platform,
	  config: {
	    user: user,
	    password: password,
	    host: host,
	    server: host,
	    port:parseInt(port),
	    database: name
	  }
	});
	
	const entry = db.model({table: table});
	const load = {};
	load[column] = sworm.escape(JSON.stringify(event));
	console.log("Payload:" + JSON.stringify(load));
	const payload = entry(load);
	
	return new Promise((resolve, reject)=>{
        payload.save().then(function(){
            console.log("Saved entry");
            db.close();
            resolve(JSON.stringify("OK"));
        }).catch((err)=>{
            console.log("Captured error during entry saving: ",err);
            db.close();
            reject(err);
        });
    });

	
};