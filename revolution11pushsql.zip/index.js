const platform = process.env.DB_PLATFORM;
const name = process.env.DB_NAME;
const table = process.env.DB_TABLE;
const column = process.env.DB_COLUMN;
const user = process.env.DB_USER;
const password = process.env.DB_PASS;
const host = process.env.DB_HOST;
const port = process.env.DB_PORT;

var sworm = require('sworm');


exports.handler = (event) => {
	console.log(`Sending to ${host}:${port}`);

	var db = sworm.db({
	  driver: platform,
	  config: {
	    user: user,
	    password: password,
	    host: host,
	    server: host,
	    port:parseInt(port),
	    database: name
	  }
	});
	 
	var entry = db.model({table: table});
	var load = {};
	load[column] = sworm.escape(JSON.stringify(event));
	console.log("Payload:" + JSON.stringify(load));
	var payload = entry(load);
	var status = 0;
	
	db.connect(function(){
		console.log("Connected to database");
		return payload.save().then(function(){
			status = 200;
			console.log("Saved entry");
		})
	}).then(function () {
		console.log("Disconnected successfully from database!");
	});
	
    const response = {
        statusCode: status,
        body: JSON.stringify("Hello")
    };

    return response;
};